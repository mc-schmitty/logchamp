Welcome to LogChamp. Lauch Logchamp.exe to continue.

Move with wasd or arrow keys, use space to swing your axe.
No axe animation yet, but you can cut down trees, targets, and reflect logs.
Launch logs for different objectives, from elf hunting to cabin building.
Watch out for falling trees! If a tree falls on you, you won't feel so good.

Currently, there is no win conditions, so
Sandbox: Do what you want! Have fun with all the game resources.
Time Trial: Cut down all the trees as fast as you can! Theres no timer so you can take your time I won't tell anyone.
Target Practice: Knock out all the targets! 
Log Cabin Build: Construct a nice log cabin by chucking wood at it. Five logs to complete!

Reset level and Main menu buttons are in the bottom left corner, idk why theyre so tiny dont @me.
Should be compatible with Windows 7 and over. Do @me if something doesn't work.

Have fun, and get chopping!
btw without this readme the game would be 66.6mb so this readme prevents the curse.